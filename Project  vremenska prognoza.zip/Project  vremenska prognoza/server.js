const express= require('express');
const request=require('request');
const app= express();

app.use(express.static("sajt"));

let temperatura;
let opis;
let gradIme;

var url= "https://api.openweathermap.org/data/2.5/weather?q=";
var kljuc= "3709f89e826c2838310e77a773533f2d&lang=sr";

app.get('/weather',(req,res)=>{
    const address = req.query.address
    if(!address) {
        return res.send({
            error: "Ukucajte ime grada u text box"
        })
    }
    console.log(address);
    var request= require('request');
    request(url+address+ '&appid=' +kljuc,function(error,response,body){
        let data=JSON.parse(body)
        if(error) {
            console.log("Ne mozemo uzeti podatke iz api-a ", undefined)
        } else if(!data.main || !data.main.temp || !data.name || !data.weather) {
            console.log("Nije moguce ucitati podatke , pokusajte drugu lokaciju", undefined);
        } else {
            temperatura= data.main.temp,
                opis= data.weather[0].description,
                gradIme= data.name
            res.send({
                temperatura,
                opis,
                gradIme
            })
            
           
           console.log("Temperatura je:"+(temperatura - 273.5).toFixed(2) + String.fromCharCode(176)+" opis "+opis+" grad "+gradIme);
        }
    })
    

})

app.get('*',(req,res)=>{
    res.send("Stranica nije ucitana");
    console.log("Lose ucitan sajt");
})


app.listen(3000,()=>console.log('Server se upalio na portu: 3000'));