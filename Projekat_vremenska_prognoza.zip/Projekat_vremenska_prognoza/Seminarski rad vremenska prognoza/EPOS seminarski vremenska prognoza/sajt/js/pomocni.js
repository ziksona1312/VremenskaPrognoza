var fetchWeather = "/weather";



const forma = document.querySelector('form');
const search = document.querySelector('input');

const opisVremena = document.querySelector('.weatherCondition');

const temp = document.querySelector('.temperature span');

const grad = document.querySelector('.place');

const datum = document.querySelector('.date');

const meseci = ["Јануар", "Фебруар", "Март", "Април", "Мај", "Јун", "Јул", "Август", "Септембар", "Октобар", "Новембар", "Децембар"]

datum.textContent = new Date().getDate() + ", " + meseci[new Date().getMonth()].substring(0, 3);


forma.addEventListener('submit', (event) => {
    event.preventDefault();
    grad.textContent = "Ucitavanje...";
    temp.textContent = "";
    opisVremena.textContent = "";
    const locationApi = fetchWeather + "?address=" + search.value;

    console.log("Ucitavanje prvi deo i tako to");

    fetch(locationApi).then(response => {
        response.json().then(data => {
            console.log(data.gradIme);
            
            if(data.error) {
                grad.textContent = data.error;
                temp.textContent = "";
                opisVremena.textContent = "";
            } else {
                console.log()
               
                grad.textContent = data.gradIme;
                temp.textContent = (data.temperatura - 273.5).toFixed(2) + String.fromCharCode(176);
                opisVremena.textContent = data.opis;
            }
        }) 
    });

    
})